module.exports = {
  password: 'Linus18!!'
}
