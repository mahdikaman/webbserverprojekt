const mongoose = require('mongoose')

const reviewSchema = new mongoose.Schema(
  {
    movieId: String,
    movie: String,
    review: String,
    rating: Number
  },
  {
    timestamps: true
  }
)

const Review = mongoose.model('movieReview', reviewSchema)
module.exports = Review
